<?php
/**
 * Webkul Software.
 * 
 * PHP version 7.0+
 *
 * @category  Webkul
 * @package   Webkul_MobikulApi
 * @author    Webkul <support@webkul.com>
 * @copyright Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html ASL Licence
 * @link      https://store.webkul.com/license.html
 */

namespace Webkul\MobikulApi\Controller\File;

use Magento\Framework\App\Response\Http;

class Uploader extends \Magento\Framework\File\Uploader
{

    /**
     * Validate callbacks storage
     *
     * @var array
     * @access protected
     */
    protected $_validateCallbacks = [];

    public function __construct(
        $fileId =  "",
        \Magento\Framework\File\Mime $fileMime = null,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList = null
    ) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $urlInterface = $objectManager->create(\Magento\Framework\UrlInterface::class);
        $resultRedirectFactory = $objectManager->create(\Magento\Framework\Controller\Result\RedirectFactory::class);
        $url = $urlInterface->getCurrentUrl();
        
        if (strpos($url, "mobikulhttp/index/uploadbannerpic") == true) {
            return $resultRedirectFactory->create()->setPath(
                'mobikulhttp/index/uploadbannerpic'
            );
        } elseif (strpos($url, "mobikulhttp/index/uploadprofilepic") == true) {
            return $resultRedirectFactory->create()->setPath(
                'mobikulhttp/index/uploadprofilepic'
            );
        } else {
            parent::__construct(
                $fileId,
                $fileMime,
                $directoryList
            );
        }
    }


    /**
     * Move files from TMP folder into destination folder
     *
     * @param string $tmpPath
     * @param string $destPath
     * @return bool|void
     */
    public function _moveFile($tmpPath, $destPath)
    {
        if (is_uploaded_file($tmpPath)) {
            return move_uploaded_file($tmpPath, $destPath);
        } elseif (is_file($tmpPath)) {
            return rename($tmpPath, $destPath);
        }
    }

    /**
     * Validate file before save
     *
     * @return void
     * @throws ValidationException
     */
    protected function _validateFile()
    {
        if ($this->_fileExists === false) {
            return;
        }

        //is file extension allowed
        if (!$this->checkAllowedExtension($this->getFileExtension())) {
            throw new ValidationException(__('Disallowed file type.'));
        }
        //run validate callbacks
        foreach ($this->_validateCallbacks as $params) {
            if (is_object($params['object'])
                && method_exists($params['object'], $params['method'])
                && is_callable([$params['object'], $params['method']])
            ) {
                $params['object']->{$params['method']}($this->_file['tmp_name']);
            }
        }
    }

}